import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { Toaster } from 'sonner'
import blink from './blink/client'
import LandingPage from './pages/LandingPage'
import Dashboard from './pages/Dashboard'
import ScanResults from './pages/ScanResults'
import Pricing from './pages/Pricing'
import AdminPanel from './pages/AdminPanel'
import ProfileSettings from './pages/ProfileSettings'
import LoadingScreen from './components/LoadingScreen'

function App() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const unsubscribe = blink.auth.onAuthStateChanged((state) => {
      setUser(state.user)
      setLoading(state.isLoading)
    })
    return unsubscribe
  }, [])

  if (loading) {
    return <LoadingScreen />
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Router>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/dashboard" element={user ? <Dashboard /> : <LandingPage />} />
          <Route path="/scan/:scanId" element={user ? <ScanResults /> : <LandingPage />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/admin" element={user ? <AdminPanel /> : <LandingPage />} />
          <Route path="/profile" element={user ? <ProfileSettings /> : <LandingPage />} />
        </Routes>
      </Router>
      <Toaster position="top-right" />
    </div>
  )
}

export default App