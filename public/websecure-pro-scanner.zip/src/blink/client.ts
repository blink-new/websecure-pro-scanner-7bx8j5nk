import { createClient } from '@blinkdotnew/sdk'

export const blink = createClient({
  projectId: 'websecure-pro-scanner-7bx8j5nk',
  authRequired: true
})

export default blink